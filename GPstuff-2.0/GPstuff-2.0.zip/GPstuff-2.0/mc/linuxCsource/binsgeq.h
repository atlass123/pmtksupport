/* Copyright (c) 1998-2004 Aki Vehtari  
 *
 *This software is distributed under the GNU General Public 
 *License (version 2 or later); please refer to the file 
 *License.txt, included with the software, for details.
 *
 */

double binsgeq(double *, int, double);
